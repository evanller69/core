Readme of VSC SDK
=================

1. VSC SDK install/uninstall

   Run "install.bat" to install the driver & SDK COM object, and run "uninstall.bat" to uninstall the driver & SDK COM object, please check these two files to see how it works.

   [NOTE] 
   1). Command to install the driver: "devcon.exe install driver\VAud_WDM.inf VAud_WDM", for win10+, please use the driver under driver_w10 folder;
   2). Command to install the COM object: "regsvr32 VSCSDK.dll";
   3). Please use 64bits version files (under [x64] folder) on 64bits OS in your own installer.

2. VSC SDK interface

   VSC SDK is a COM object, with following functions and properties:

   1). OpenInterface();
   Find the driver and open the interface to communicate with it;

   2). CloseInterface();
   Close the interface opened by OpenInterface(), release the resource;

   3). SetLicenseCode(BSTR);
   Set the license code, so the noise of the output sound will be removed and the driver will be registered.
   NOTE: for one PC, call once is enough. the registration information will be save;

   4). RestartDriver();
   If you changed something such as InstanceCount or VolumeControlEnanled, you need to call this function to make it affect immediately.
   NOTE: 
      1. Please call CloseInterface() before calling this function, otherwise a PC reboot is required to accept your changes.
      2. It's a better choice to run "driver_restart.bat" to restart the driver;

   5). InstanceCount - get/set Property
   Get or Set driver instance count (same feature like e2eSoft VSC application);

   6). VolumeControlEnabled - get/set Property
   Get or Set VolumeControlEnabled for all instances of the driver (same feature like e2eSoft VSC application).

3. Files list
   [driver] folder is the VSC driver;
   [VSCSDKTest.zip] is a C# test application for the VSC SDK, please check its code to see how VSC SDK works;
   [audiorepeater.exe] is a small tools used to transfer one sound card's sound to another one, just like what e2eSoft VSC does, for your TEST only.

4. License
   VSC SDK is a shareware, you can trial it freely before purchase.
   One license code can only be used for one application. You need to buy more licenses if you want to use VSC SDK for more applications. 

5. Contact
   Please mail to service@e2esoft.cn to get support.
   You can visit our website as well - www.e2esoft.cn
